1. Install dependencies:
pip install flask requests beautifulsoup4
2. Run it:
python google_scraper_api.py
3. Test endpoints:
Single page (with pagination):
# Page 1
curl "http://localhost:5000/search?q=python&page=1"

# Page 2
curl "http://localhost:5000/search?q=python&page=2"

# Page 3
curl "http://localhost:5000/search?q=python&page=3"
All pages (scrape everything):
# Scrape up to 10 pages
curl "http://localhost:5000/search/all?q=python&max_pages=10"

# Scrape up to 5 pages
curl "http://localhost:5000/search/all?q=artificial+intelligence&max_pages=5"
Check API status:
curl "http://localhost:5000/"
Features:
✅ Single script - no extra files
✅ Pagination support (/search?q=query&page=2)
✅ All-page scraping (/search/all?q=query&max_pages=10)
✅ Auto cookie refresh
✅ JSON responses
✅ Ready for Railway/DigitalOcean deployment
Just run and start scraping!